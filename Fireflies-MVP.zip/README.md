# Fireflies MVP

Fireflies is a polished front-end MVP for an AI digital-product creation and commercialization platform.

## Included
- Landing page
- Authentication screen
- Creator dashboard
- Niche selector
- Survival Pain Analyzer
- AI Product Builder
- Design Studio
- Media Studio
- Research Assistant
- Originality Assistant
- Advertising Command Centre
- Monetization Hub
- Analytics
- API & Integrations
- Subscription page

## Deploy to Vercel
This MVP is intentionally a static single-page app, so it can be deployed immediately:

1. Put `index.html` in a GitHub repository.
2. Import the repository into Vercel.
3. Use the project root as the root directory.
4. No build command is required for this prototype.
5. Deploy.

## Production roadmap
The interface is a front-end prototype. Real authentication, billing, file storage, AI generation, OAuth, API keys, webhooks, research citations, YouTube/social publishing and analytics require a secure backend.

Recommended production stack:
- Next.js / TypeScript
- PostgreSQL
- Object storage such as S3/R2
- Server-side API routes
- n8n or equivalent orchestration
- OAuth 2.0 for external platforms
- Stripe or a suitable billing provider
- AI providers for text, image, video and audio
- FFmpeg or a media rendering service
